﻿using System;

namespace loadTestCallHandler
{
    class Program
    {
        static void Main(string[] args)
        {
             Console.WriteLine("program started running at " + System.DateTime.Now);
        
            Console.WriteLine("Hello World!");
            Console.WriteLine("launching first browser tab");
            //System.Diagnostics.Process.Start(@"start https://google.com");
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo { FileName = "https://www.google.com", UseShellExecute = true });
            
            
            Console.WriteLine("opening second tab");
            string url = "https://apps.powerapps.com/play/e/b40ca521-7d99-44d3-8836-bb8cf7c7f722/a/171eeb64-9c0f-413b-9658-94b08c8d48de?tenantId=37bfc38e-7b8f-4bb9-8dd9-66212c4029da&source=portal&&name=CALL%20FROM&phoneNumber=7866332083&passedDigits=&VDN=%3Cvdn%3E&userToUser=&agentAcceptedCall=1713887035&agentEndedCall=1713887035&callStartedDate=1713887035&callEndedDate=1713887035&agentID=1446&stationID=6312&ucid=&vdnTime=&asai=#";
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo { FileName = url , UseShellExecute = true });
            Console.WriteLine("program ended running at " + System.DateTime.Now);
        Console.WriteLine("press any key to continue...");
        Console.Read();
        }
    }
}


/*

https://apps.powerapps.com/play/e/b40ca521-7d99-44d3-8836-bb8cf7c7f722/a/171eeb64-9c0f-413b-9658-94b08c8d48de?tenantId=37bfc38e-7b8f-4bb9-8dd9-66212c4029da&source=portal&&name=CALL%20FROM&phoneNumber=7866332083&passedDigits=&VDN=%3Cvdn%3E&userToUser=&agentAcceptedCall=1713887035&agentEndedCall=1713887035&callStartedDate=1713887035&callEndedDate=1713887035&agentID=1446&stationID=6312&ucid=&vdnTime=&asai=#

https://apps.powerapps.com/play/e/b40ca521-7d99-44d3-8836-bb8cf7c7f722/a/171eeb64-9c0f-413b-9658-94b08c8d48de?tenantId=37bfc38e-7b8f-4bb9-8dd9-66212c4029da&source=portal&&name=CALL%20FROM&phoneNumber=9048663765&passedDigits=&VDN=%3Cvdn%3E&userToUser=&agentAcceptedCall=1713887035&agentEndedCall=1713887035&callStartedDate=1713887035&callEndedDate=1713887035&agentID=1446&stationID=6312&ucid=&vdnTime=&asai=#

https://apps.powerapps.com/play/e/b40ca521-7d99-44d3-8836-bb8cf7c7f722/a/171eeb64-9c0f-413b-9658-94b08c8d48de?tenantId=37bfc38e-7b8f-4bb9-8dd9-66212c4029da&source=portal&&name=CALL%20FROM&phoneNumber=9145894485&passedDigits=&VDN=%3Cvdn%3E&userToUser=&agentAcceptedCall=1713887035&agentEndedCall=1713887035&callStartedDate=1713887035&callEndedDate=1713887035&agentID=1446&stationID=6312&ucid=&vdnTime=&asai=#

https://apps.powerapps.com/play/e/b40ca521-7d99-44d3-8836-bb8cf7c7f722/a/171eeb64-9c0f-413b-9658-94b08c8d48de?tenantId=37bfc38e-7b8f-4bb9-8dd9-66212c4029da&source=portal&&name=CALL%20FROM&phoneNumber=9567234901&passedDigits=&VDN=%3Cvdn%3E&userToUser=&agentAcceptedCall=1713887035&agentEndedCall=1713887035&callStartedDate=1713887035&callEndedDate=1713887035&agentID=1446&stationID=6312&ucid=&vdnTime=&asai=#

https://apps.powerapps.com/play/e/b40ca521-7d99-44d3-8836-bb8cf7c7f722/a/171eeb64-9c0f-413b-9658-94b08c8d48de?tenantId=37bfc38e-7b8f-4bb9-8dd9-66212c4029da&source=portal&&name=CALL%20FROM&phoneNumber=3526725340&passedDigits=&VDN=%3Cvdn%3E&userToUser=&agentAcceptedCall=1713887035&agentEndedCall=1713887035&callStartedDate=1713887035&callEndedDate=1713887035&agentID=1446&stationID=6312&ucid=&vdnTime=&asai=#

https://apps.powerapps.com/play/e/b40ca521-7d99-44d3-8836-bb8cf7c7f722/a/171eeb64-9c0f-413b-9658-94b08c8d48de?tenantId=37bfc38e-7b8f-4bb9-8dd9-66212c4029da&source=portal&&name=CALL%20FROM&phoneNumber=8799843810&passedDigits=&VDN=%3Cvdn%3E&userToUser=&agentAcceptedCall=1713887035&agentEndedCall=1713887035&callStartedDate=1713887035&callEndedDate=1713887035&agentID=1446&stationID=6312&ucid=&vdnTime=&asai=#

https://apps.powerapps.com/play/e/b40ca521-7d99-44d3-8836-bb8cf7c7f722/a/171eeb64-9c0f-413b-9658-94b08c8d48de?tenantId=37bfc38e-7b8f-4bb9-8dd9-66212c4029da&source=portal&&name=CALL%20FROM&phoneNumber=9047906175&passedDigits=&VDN=%3Cvdn%3E&userToUser=&agentAcceptedCall=1713887035&agentEndedCall=1713887035&callStartedDate=1713887035&callEndedDate=1713887035&agentID=1446&stationID=6312&ucid=&vdnTime=&asai=#

https://apps.powerapps.com/play/e/b40ca521-7d99-44d3-8836-bb8cf7c7f722/a/171eeb64-9c0f-413b-9658-94b08c8d48de?tenantId=37bfc38e-7b8f-4bb9-8dd9-66212c4029da&source=portal&&name=CALL%20FROM&phoneNumber=9048102231&passedDigits=&VDN=%3Cvdn%3E&userToUser=&agentAcceptedCall=1713887035&agentEndedCall=1713887035&callStartedDate=1713887035&callEndedDate=1713887035&agentID=1446&stationID=6312&ucid=&vdnTime=&asai=#

https://apps.powerapps.com/play/e/b40ca521-7d99-44d3-8836-bb8cf7c7f722/a/171eeb64-9c0f-413b-9658-94b08c8d48de?tenantId=37bfc38e-7b8f-4bb9-8dd9-66212c4029da&source=portal&&name=CALL%20FROM&phoneNumber=7445980231&passedDigits=&VDN=%3Cvdn%3E&userToUser=&agentAcceptedCall=1713887035&agentEndedCall=1713887035&callStartedDate=1713887035&callEndedDate=1713887035&agentID=1446&stationID=6312&ucid=&vdnTime=&asai=#

https://apps.powerapps.com/play/e/b40ca521-7d99-44d3-8836-bb8cf7c7f722/a/171eeb64-9c0f-413b-9658-94b08c8d48de?tenantId=37bfc38e-7b8f-4bb9-8dd9-66212c4029da&source=portal&&name=CALL%20FROM&phoneNumber=7576767604&passedDigits=&VDN=%3Cvdn%3E&userToUser=&agentAcceptedCall=1713887035&agentEndedCall=1713887035&callStartedDate=1713887035&callEndedDate=1713887035&agentID=1446&stationID=6312&ucid=&vdnTime=&asai=#

https://apps.powerapps.com/play/e/b40ca521-7d99-44d3-8836-bb8cf7c7f722/a/171eeb64-9c0f-413b-9658-94b08c8d48de?tenantId=37bfc38e-7b8f-4bb9-8dd9-66212c4029da&source=portal&&name=CALL%20FROM&phoneNumber=8744512034&passedDigits=&VDN=%3Cvdn%3E&userToUser=&agentAcceptedCall=1713887035&agentEndedCall=1713887035&callStartedDate=1713887035&callEndedDate=1713887035&agentID=1446&stationID=6312&ucid=&vdnTime=&asai=#

https://apps.powerapps.com/play/e/b40ca521-7d99-44d3-8836-bb8cf7c7f722/a/171eeb64-9c0f-413b-9658-94b08c8d48de?tenantId=37bfc38e-7b8f-4bb9-8dd9-66212c4029da&source=portal&&name=CALL%20FROM&phoneNumber=9047606046&passedDigits=&VDN=%3Cvdn%3E&userToUser=&agentAcceptedCall=1713887035&agentEndedCall=1713887035&callStartedDate=1713887035&callEndedDate=1713887035&agentID=1446&stationID=6312&ucid=&vdnTime=&asai=#

https://apps.powerapps.com/play/e/b40ca521-7d99-44d3-8836-bb8cf7c7f722/a/171eeb64-9c0f-413b-9658-94b08c8d48de?tenantId=37bfc38e-7b8f-4bb9-8dd9-66212c4029da&source=portal&&name=CALL%20FROM&phoneNumber=3522584362&passedDigits=&VDN=%3Cvdn%3E&userToUser=&agentAcceptedCall=1713887035&agentEndedCall=1713887035&callStartedDate=1713887035&callEndedDate=1713887035&agentID=1446&stationID=6312&ucid=&vdnTime=&asai=#

https://apps.powerapps.com/play/e/b40ca521-7d99-44d3-8836-bb8cf7c7f722/a/171eeb64-9c0f-413b-9658-94b08c8d48de?tenantId=37bfc38e-7b8f-4bb9-8dd9-66212c4029da&source=portal&&name=CALL%20FROM&phoneNumber=4073537893&passedDigits=&VDN=%3Cvdn%3E&userToUser=&agentAcceptedCall=1713887035&agentEndedCall=1713887035&callStartedDate=1713887035&callEndedDate=1713887035&agentID=1446&stationID=6312&ucid=&vdnTime=&asai=#

https://apps.powerapps.com/play/e/b40ca521-7d99-44d3-8836-bb8cf7c7f722/a/171eeb64-9c0f-413b-9658-94b08c8d48de?tenantId=37bfc38e-7b8f-4bb9-8dd9-66212c4029da&source=portal&&name=CALL%20FROM&phoneNumber=6502530000&passedDigits=&VDN=%3Cvdn%3E&userToUser=&agentAcceptedCall=1713887035&agentEndedCall=1713887035&callStartedDate=1713887035&callEndedDate=1713887035&agentID=1446&stationID=6312&ucid=&vdnTime=&asai=#

https://apps.powerapps.com/play/e/b40ca521-7d99-44d3-8836-bb8cf7c7f722/a/171eeb64-9c0f-413b-9658-94b08c8d48de?tenantId=37bfc38e-7b8f-4bb9-8dd9-66212c4029da&source=portal&&name=CALL%20FROM&phoneNumber=2163923251&passedDigits=&VDN=%3Cvdn%3E&userToUser=&agentAcceptedCall=1713887035&agentEndedCall=1713887035&callStartedDate=1713887035&callEndedDate=1713887035&agentID=1446&stationID=6312&ucid=&vdnTime=&asai=#

https://apps.powerapps.com/play/e/b40ca521-7d99-44d3-8836-bb8cf7c7f722/a/171eeb64-9c0f-413b-9658-94b08c8d48de?tenantId=37bfc38e-7b8f-4bb9-8dd9-66212c4029da&source=portal&&name=CALL%20FROM&phoneNumber=9043122150&passedDigits=&VDN=%3Cvdn%3E&userToUser=&agentAcceptedCall=1713887035&agentEndedCall=1713887035&callStartedDate=1713887035&callEndedDate=1713887035&agentID=1446&stationID=6312&ucid=&vdnTime=&asai=#

https://apps.powerapps.com/play/e/b40ca521-7d99-44d3-8836-bb8cf7c7f722/a/171eeb64-9c0f-413b-9658-94b08c8d48de?tenantId=37bfc38e-7b8f-4bb9-8dd9-66212c4029da&source=portal&&name=CALL%20FROM&phoneNumber=9043765765&passedDigits=&VDN=%3Cvdn%3E&userToUser=&agentAcceptedCall=1713887035&agentEndedCall=1713887035&callStartedDate=1713887035&callEndedDate=1713887035&agentID=1446&stationID=6312&ucid=&vdnTime=&asai=#

https://apps.powerapps.com/play/e/b40ca521-7d99-44d3-8836-bb8cf7c7f722/a/171eeb64-9c0f-413b-9658-94b08c8d48de?tenantId=37bfc38e-7b8f-4bb9-8dd9-66212c4029da&source=portal&&name=CALL%20FROM&phoneNumber=9065750009&passedDigits=&VDN=%3Cvdn%3E&userToUser=&agentAcceptedCall=1713887035&agentEndedCall=1713887035&callStartedDate=1713887035&callEndedDate=1713887035&agentID=1446&stationID=6312&ucid=&vdnTime=&asai=#

https://apps.powerapps.com/play/e/b40ca521-7d99-44d3-8836-bb8cf7c7f722/a/171eeb64-9c0f-413b-9658-94b08c8d48de?tenantId=37bfc38e-7b8f-4bb9-8dd9-66212c4029da&source=portal&&name=CALL%20FROM&phoneNumber=9042847368&passedDigits=&VDN=%3Cvdn%3E&userToUser=&agentAcceptedCall=1713887035&agentEndedCall=1713887035&callStartedDate=1713887035&callEndedDate=1713887035&agentID=1446&stationID=6312&ucid=&vdnTime=&asai=#

https://apps.powerapps.com/play/e/b40ca521-7d99-44d3-8836-bb8cf7c7f722/a/171eeb64-9c0f-413b-9658-94b08c8d48de?tenantId=37bfc38e-7b8f-4bb9-8dd9-66212c4029da&source=portal&&name=CALL%20FROM&phoneNumber=3866711774&passedDigits=&VDN=%3Cvdn%3E&userToUser=&agentAcceptedCall=1713887035&agentEndedCall=1713887035&callStartedDate=1713887035&callEndedDate=1713887035&agentID=1446&stationID=6312&ucid=&vdnTime=&asai=#

https://apps.powerapps.com/play/e/b40ca521-7d99-44d3-8836-bb8cf7c7f722/a/171eeb64-9c0f-413b-9658-94b08c8d48de?tenantId=37bfc38e-7b8f-4bb9-8dd9-66212c4029da&source=portal&&name=CALL%20FROM&phoneNumber=9048612365&passedDigits=&VDN=%3Cvdn%3E&userToUser=&agentAcceptedCall=1713887035&agentEndedCall=1713887035&callStartedDate=1713887035&callEndedDate=1713887035&agentID=1446&stationID=6312&ucid=&vdnTime=&asai=#

https://apps.powerapps.com/play/e/b40ca521-7d99-44d3-8836-bb8cf7c7f722/a/171eeb64-9c0f-413b-9658-94b08c8d48de?tenantId=37bfc38e-7b8f-4bb9-8dd9-66212c4029da&source=portal&&name=CALL%20FROM&phoneNumber=5622387543&passedDigits=&VDN=%3Cvdn%3E&userToUser=&agentAcceptedCall=1713887035&agentEndedCall=1713887035&callStartedDate=1713887035&callEndedDate=1713887035&agentID=1446&stationID=6312&ucid=&vdnTime=&asai=#

https://apps.powerapps.com/play/e/b40ca521-7d99-44d3-8836-bb8cf7c7f722/a/171eeb64-9c0f-413b-9658-94b08c8d48de?tenantId=37bfc38e-7b8f-4bb9-8dd9-66212c4029da&source=portal&&name=CALL%20FROM&phoneNumber=9043056791&passedDigits=&VDN=%3Cvdn%3E&userToUser=&agentAcceptedCall=1713887035&agentEndedCall=1713887035&callStartedDate=1713887035&callEndedDate=1713887035&agentID=1446&stationID=6312&ucid=&vdnTime=&asai=#

https://apps.powerapps.com/play/e/b40ca521-7d99-44d3-8836-bb8cf7c7f722/a/171eeb64-9c0f-413b-9658-94b08c8d48de?tenantId=37bfc38e-7b8f-4bb9-8dd9-66212c4029da&source=portal&&name=CALL%20FROM&phoneNumber=9042506672&passedDigits=&VDN=%3Cvdn%3E&userToUser=&agentAcceptedCall=1713887035&agentEndedCall=1713887035&callStartedDate=1713887035&callEndedDate=1713887035&agentID=1446&stationID=6312&ucid=&vdnTime=&asai=#

https://apps.powerapps.com/play/e/b40ca521-7d99-44d3-8836-bb8cf7c7f722/a/171eeb64-9c0f-413b-9658-94b08c8d48de?tenantId=37bfc38e-7b8f-4bb9-8dd9-66212c4029da&source=portal&&name=CALL%20FROM&phoneNumber=9042497402&passedDigits=&VDN=%3Cvdn%3E&userToUser=&agentAcceptedCall=1713887035&agentEndedCall=1713887035&callStartedDate=1713887035&callEndedDate=1713887035&agentID=1446&stationID=6312&ucid=&vdnTime=&asai=#

https://apps.powerapps.com/play/e/b40ca521-7d99-44d3-8836-bb8cf7c7f722/a/171eeb64-9c0f-413b-9658-94b08c8d48de?tenantId=37bfc38e-7b8f-4bb9-8dd9-66212c4029da&source=portal&&name=CALL%20FROM&phoneNumber=8137014288&passedDigits=&VDN=%3Cvdn%3E&userToUser=&agentAcceptedCall=1713887035&agentEndedCall=1713887035&callStartedDate=1713887035&callEndedDate=1713887035&agentID=1446&stationID=6312&ucid=&vdnTime=&asai=#

https://apps.powerapps.com/play/e/b40ca521-7d99-44d3-8836-bb8cf7c7f722/a/171eeb64-9c0f-413b-9658-94b08c8d48de?tenantId=37bfc38e-7b8f-4bb9-8dd9-66212c4029da&source=portal&&name=CALL%20FROM&phoneNumber=2514014049&passedDigits=&VDN=%3Cvdn%3E&userToUser=&agentAcceptedCall=1713887035&agentEndedCall=1713887035&callStartedDate=1713887035&callEndedDate=1713887035&agentID=1446&stationID=6312&ucid=&vdnTime=&asai=#

https://apps.powerapps.com/play/e/b40ca521-7d99-44d3-8836-bb8cf7c7f722/a/171eeb64-9c0f-413b-9658-94b08c8d48de?tenantId=37bfc38e-7b8f-4bb9-8dd9-66212c4029da&source=portal&&name=CALL%20FROM&phoneNumber=9047550648&passedDigits=&VDN=%3Cvdn%3E&userToUser=&agentAcceptedCall=1713887035&agentEndedCall=1713887035&callStartedDate=1713887035&callEndedDate=1713887035&agentID=1446&stationID=6312&ucid=&vdnTime=&asai=#

https://apps.powerapps.com/play/e/b40ca521-7d99-44d3-8836-bb8cf7c7f722/a/171eeb64-9c0f-413b-9658-94b08c8d48de?tenantId=37bfc38e-7b8f-4bb9-8dd9-66212c4029da&source=portal&&name=CALL%20FROM&phoneNumber=5398765365&passedDigits=&VDN=%3Cvdn%3E&userToUser=&agentAcceptedCall=1713887035&agentEndedCall=1713887035&callStartedDate=1713887035&callEndedDate=1713887035&agentID=1446&stationID=6312&ucid=&vdnTime=&asai=#

https://apps.powerapps.com/play/e/b40ca521-7d99-44d3-8836-bb8cf7c7f722/a/171eeb64-9c0f-413b-9658-94b08c8d48de?tenantId=37bfc38e-7b8f-4bb9-8dd9-66212c4029da&source=portal&&name=CALL%20FROM&phoneNumber=9048123765&passedDigits=&VDN=%3Cvdn%3E&userToUser=&agentAcceptedCall=1713887035&agentEndedCall=1713887035&callStartedDate=1713887035&callEndedDate=1713887035&agentID=1446&stationID=6312&ucid=&vdnTime=&asai=#

*/
